
--create table agent assurance

CREATE TABLE [dbo].[Assurance] (
    [id_Assurance]        INT        IDENTITY (1, 1) NOT NULL,
    [Nom_Assurance]                VARCHAR (150)   NOT NULL,
    PRIMARY KEY CLUSTERED ([id_Assurance] ASC)
);
insert into Assurance(Nom_Assurance)
       values ('Non assure');

--create table groupSang

CREATE TABLE [dbo].[GroupSang] (
    [id_GroupSang]        INT        IDENTITY (1, 1) NOT NULL,
    [Nom_GroupSang]                VARCHAR (10)   NOT NULL,
    PRIMARY KEY CLUSTERED ([id_GroupSang] ASC)
);
insert into GroupSang(Nom_GroupSang)
       values ('aucun'),('A+'), ('A-'), ('AB+'), ('AB-'),('O+'),('O-');

--create table Patient
CREATE TABLE [dbo].[Patient] (
    [id_patient]        INT        IDENTITY (1, 1) NOT NULL,
    [Nom_patient]                NVARCHAR (50)   NOT NULL,
    [Prenom_patient]            NVARCHAR (50)     NOT   NULL,
    [CIN_patient]          VARCHAR (8)       NOT NULL,
    [DateNaissance]        Date        NOT  NULL,
    [Sex]      char       NOT NULL,
    [LieuNaissance]          NVARCHAR (50)  NULL,
    [Phone_patient]            VARCHAR (10)  NULL,
    [Email_patient]    NVARCHAR (100)  NULL,
    [Address_patient]    NVARCHAR (200)  NULL,
	[Profession_patient]    NVARCHAR (200)  NULL,
    [Age_patient]    INT  NOT NULL,
	[DateSave_patient]   Date   DEFAULT (getdate()) NOT NULL,
	[EtatCivil] VARCHAR(100)  NULL,
	[Assurance_id] INT  NULL,
	[GroupSang_id] INT  NULL,
    PRIMARY KEY CLUSTERED ([id_patient] ASC),
	CONSTRAINT [fk_Assurance] FOREIGN KEY ([Assurance_id]) REFERENCES [dbo].[Assurance] ([id_Assurance]),
	CONSTRAINT [fk_GroupSang] FOREIGN KEY ([GroupSang_id]) REFERENCES [dbo].[GroupSang] ([id_GroupSang])
);

--create table rendez vous

CREATE TABLE [dbo].[RendezVous] (
    [Id]          INT            IDENTITY (8, 1) NOT NULL,
    [date]        DATETIME       NULL,
    [heure]       TIME (7)       NULL,
    [id_patient]  INT            NULL,
    [type]        NVARCHAR (50)  NULL,
    [description] NVARCHAR (300) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_Table_ToTable1] FOREIGN KEY ([id_patient]) REFERENCES [dbo].[Patient] ([id_patient]) 
);

--Create table consultation
CREATE TABLE [dbo].[Consultation] (
    [id_Consult]        INT        IDENTITY (1, 1) NOT NULL,
    [Motif_Consult]            NVARCHAR (500)    NOT NULL,
    [Date_Consult]         Date     NOT NULL,
	[ExamenClinque_Consult]                NVARCHAR (1000)    NULL,
    [Diagnostique_Consult]       Nvarchar(1000)   NULL,
	[Poids_patient] DECIMAL(8,1)  NULL,
	[Taille_patient] int  NULL,
    [Terminer_Consult]      int       NOT NULL,
	[Patient_id] INT NOT  NULL,
    PRIMARY KEY CLUSTERED ([id_Consult] ASC),
	CONSTRAINT [fk_PatinetConsult] FOREIGN KEY ([Patient_id]) REFERENCES [dbo].[Patient] ([id_patient])
);


--Create table type analyse
CREATE TABLE [dbo].[Type_Analyse] (
    [id_TypeAN]        INT      IDENTITY (1, 1)    NOT NULL,
    [Nom_TypeAN]            VARCHAR (500)    NOT NULL,
	 PRIMARY KEY CLUSTERED ([id_TypeAN] ASC)
);

--Create  table Analyse
CREATE TABLE [dbo].[Analyse] (
    [id_Analyse]        INT      IDENTITY (1, 1)    NOT NULL,
    [Nom_Analyse]            VARCHAR (500)    NOT NULL,
	[Type_Analyse_id]  INT NOT  NULL,
	 PRIMARY KEY CLUSTERED ([id_Analyse] ASC),
	 CONSTRAINT [fk_AnalyseType] FOREIGN KEY ([Type_Analyse_id]) REFERENCES [dbo].[Type_Analyse] ([id_TypeAN])
);
--Create table result Analyse
CREATE TABLE [dbo].[Bilans] (
    [Consult_id]        INT     NOT NULL,
    [Date_Bilan]        date NOT  NULL,
    [Analyse_id]            INT   NOT NULL,
	[Result_Analyse]  Nvarchar(1000)  NULL,
	 CONSTRAINT PK_result PRIMARY KEY (Consult_id, Analyse_id),
    CONSTRAINT FK_Consultation_ID1 FOREIGN KEY (Consult_id) REFERENCES Consultation(id_Consult),
    CONSTRAINT FK_Analyse_ID2 FOREIGN KEY (Analyse_id) REFERENCES Analyse(id_Analyse)
);


--Create type antécédents
CREATE TABLE [dbo].[Type_Antecedent] (
    [id_TypeAtecd]        INT        IDENTITY (1, 1) NOT NULL,
    [Nom_TypeAtecd]      VARCHAR (500)    NOT NULL,
	 PRIMARY KEY CLUSTERED ([id_TypeAtecd] ASC)
);
--Create table antecedents de patient
CREATE TABLE [dbo].[Antecedents] (
    [patient_id]        INT     NOT NULL,
    [Date_Anteced]     date NOT  NULL,
    [TypeAtecd_id]            INT   NOT NULL,
	[Descrip_Antecedent]  Nvarchar(1000)  NULL,
	 CONSTRAINT PK_Antecedent PRIMARY KEY (patient_id, TypeAtecd_id),
    CONSTRAINT FK_patientANted_ID1 FOREIGN KEY (patient_id) REFERENCES Patient(id_patient),
    CONSTRAINT FK_typeAnteced_ID2 FOREIGN KEY (TypeAtecd_id) REFERENCES Type_Antecedent(id_TypeAtecd)
);

--create table categorie medicament
CREATE TABLE [dbo].[Categorie_Medicament] (
    [id_CatMedicament]        INT    NOT NULL,
    [Nom_CatMedicament]      VARCHAR (500)    NOT NULL,
	 PRIMARY KEY CLUSTERED ([id_CatMedicament] ASC)
);

--Create  table medicament
CREATE TABLE [dbo].[Medicament] (
    [id_Medicament]        INT     NOT NULL,
    [Nom_Medicament]       VARCHAR (500)    NOT NULL,
	[CatMedicament_id]  INT NOT  NULL,
	 PRIMARY KEY CLUSTERED ([id_Medicament] ASC),
	 CONSTRAINT [fk_CatMedicament] FOREIGN KEY ([CatMedicament_id]) REFERENCES [dbo].[Categorie_Medicament] ([id_CatMedicament])
);
--Create table ordonnance
CREATE TABLE [dbo].[Ordonnance] (
    [Consult_id]        INT     NOT NULL,
    [Medicament_id]            INT   NOT NULL,
    [Date_Ordonnace]     date NOT  NULL,
	[Posologie]  Nvarchar(300)  NULL,
	[Note_Supplimentaire]  Nvarchar(1000)  NULL,
	[Quantite]  INT,
	 CONSTRAINT PK_Ordonnace PRIMARY KEY (Consult_id, Medicament_id),
   CONSTRAINT FK_Consultation_ordonnace_ID1 FOREIGN KEY (Consult_id) REFERENCES Consultation(id_Consult),
    CONSTRAINT FK_medicament_ID2 FOREIGN KEY (Medicament_id) REFERENCES Medicament(id_Medicament)
);

--create table mecine && admin
CREATE TABLE [dbo].[Utilisateur] (
    [id_user]        INT        IDENTITY (1, 1) NOT NULL,
	[Nom_user] Nvarchar(50) NOT NULL,
	[Prenom_user] Nvarchar(50) NOT NULL,
	[CIN_user] varchar(10) NOT NULL,
	[Phone_user] varchar(10)  Not NULL,
	[Email_user] Nvarchar(100)  NULL,
    [Diplome_user] Nvarchar(500)  NULL,
	[Photo_user]            varbinary(max)     NULL,
	[Status_Compte] int NOT NULL,
    [IsAdmin] int NOT NULL  DEFAULT 0 ,
    [IsConnect] integer NOT NULL  DEFAULT 0 ,
	[Role_user] int NOT NULL,
    [Login_user]    VARCHAR(50)    NOT NULL,
    [password_user]    VARCHAR(max)    NOT NULL,
    PRIMARY KEY CLUSTERED ([id_user] ASC)
);
    -- insert Data 
-- admin--
 insert into Utilisateur(Nom_user, Prenom_user, CIN_user, Phone_user, Email_user,
                    Diplome_user,Status_Compte,Role_user,Login_user, password_user,IsAdmin)
                    values ('nom','Prenom','CIN','00000000','Email@GG','Diplome',1,1,
                    'admin',ENCRYPTBYPASSPHRASE('key_user','123456'),1);


-- Table module medicament --------
CREATE TABLE [dbo].[Module_Ordonnonce] (
    [Id_Module_Ordonnonce]   INT  IDENTITY (1, 1) NOT NULL,
    [Nom_Module_Ordonnonce]                VARCHAR (150)   NOT NULL,
    PRIMARY KEY CLUSTERED ([Id_Module_Ordonnonce] ASC)
);
-- Table module analyse --------
CREATE TABLE [dbo].[Module_Bilan] (
    [Id_Module_Bilan]   INT  IDENTITY (1, 1) NOT NULL,
    [Nom_Module_Bilan]                VARCHAR (150)   NOT NULL,
    PRIMARY KEY CLUSTERED ([Id_Module_Bilan] ASC)
);

-- table moule Analyse
CREATE TABLE [dbo].[Bilan_Module] (
    [Module_Bilan_id]        INT     NOT NULL,
    [Analyse_id]            INT   NOT NULL,
    CONSTRAINT PK_bilans_module PRIMARY KEY (Module_Bilan_id, Analyse_id),
    CONSTRAINT FK_Analyse_module_ID1 FOREIGN KEY (Module_Bilan_id) REFERENCES Module_Bilan(Id_Module_Bilan) ON update  cascade on delete cascade,
    CONSTRAINT FK_Analyse_module_ID2 FOREIGN KEY (Analyse_id) REFERENCES Analyse(id_Analyse)
);

-- table ordonnance
CREATE TABLE [dbo].[Ordonnance_Module] (
    [Module_Ordonnonce_id]        INT     NOT NULL,
    [Medicament_id]            INT   NOT NULL,
    CONSTRAINT PK_Ordonnace_module PRIMARY KEY (Medicament_id, Module_Ordonnonce_id),
   CONSTRAINT FK_Medicament_module_ID1 FOREIGN KEY (Medicament_id) REFERENCES Medicament(id_Medicament) ,
    CONSTRAINT FK_medicament_module_ID2 FOREIGN KEY (Module_Ordonnonce_id) REFERENCES Module_Ordonnonce(Id_Module_Ordonnonce)ON update  cascade on delete cascade
);

--Create table prochaine rendez vous
CREATE TABLE [dbo].[Prochaine_RDV] (
    [Consult_id]        INT     NOT NULL,
    [RDV_id]            INT   NOT NULL,
	 CONSTRAINT PK_prochaine PRIMARY KEY (Consult_id, RDV_id),
    CONSTRAINT FK_Consultation_prochaine1 FOREIGN KEY (Consult_id) REFERENCES Consultation(id_Consult) on update cascade on delete cascade,
    CONSTRAINT FK_Analyse_prochaine2 FOREIGN KEY (RDV_id) REFERENCES RendezVous(Id)  on update cascade on delete cascade
);
-- la table des certificat d'aptitude physique --

CREATE TABLE [dbo].[apt_physique] (
    [Id]          INT            IDENTITY (1, 1) NOT NULL,
    [date]        DATETIME       NOT NULL,
    [nom]         NCHAR (40)     NULL,
    [cin]         NCHAR (10)     NULL,
    [aptitude]    NVARCHAR (50)  NULL,
    [description] NVARCHAR (500) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

-- la table des certificats médicaux normaux --

CREATE TABLE [dbo].[certificat] (
    [Id]         INT        IDENTITY (1, 1) NOT NULL,
    [nom]        NCHAR (40) NULL,
    [date_it]    DATETIME   NULL,
    [date_debut] NCHAR (20) NULL,
    [date_fin]   NCHAR (20) NULL,
    [type]       NCHAR (20) NULL,
    [arrete]     INT        NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

-- la table des certificats de mariage

CREATE TABLE [dbo].[mariage] (
    [Id]          INT            IDENTITY (1, 1) NOT NULL,
    [date]        DATETIME       NULL,
    [nom]         NVARCHAR (40)  NULL,
	-- nom_w == 0 si le certificat est d'aptitude de mariage pour la femme et l'homme
    [nom_w]       NVARCHAR (40)  NULL,
    [cin]         NVARCHAR (10)  NULL,
    [description] NVARCHAR (500) NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
-- tables de notification ----------
--Create table NOtification patient
CREATE TABLE [dbo].[Notification_patient] (
	[id_notification] INT      IDENTITY (1, 1)    NOT NULL,
    [patient_id]        INT     NOT NULL,
    [user_id]            INT   NOT NULL,
    [Date_notification]        date NOT  NULL ,
	[description_notification]  Nvarchar(1000)  NULL,
	 CONSTRAINT PK_notification_patient PRIMARY KEY (id_notification),
    CONSTRAINT FK_patient_notification FOREIGN KEY (patient_id) REFERENCES Patient(id_patient) on update cascade on delete cascade,
    CONSTRAINT FK_user_notification_pat FOREIGN KEY (user_id) REFERENCES Utilisateur(id_user)  on update cascade on delete cascade
);
--Create table NOtification consultation
CREATE TABLE [dbo].[Notification_Consultation] (
	[id_notification] INT      IDENTITY (1, 1)    NOT NULL,
    [consult_id]        INT     NOT NULL,
    [user_id]            INT   NOT NULL,
    [Date_notification]        date NOT  NULL ,
	[description_notification]  Nvarchar(1000)  NULL,
	 CONSTRAINT PK_notification_consultation PRIMARY KEY (id_notification),
    CONSTRAINT FK_consultation_notification FOREIGN KEY (consult_id) REFERENCES Consultation(id_Consult) on update cascade on delete cascade,
    CONSTRAINT FK_user_notification_cons FOREIGN KEY (user_id) REFERENCES Utilisateur(id_user)  on update cascade on delete cascade
);
--Create table NOtification rendez vous 
CREATE TABLE [dbo].[Notification_RendezVous] (
	[id_notification] INT      IDENTITY (1, 1)    NOT NULL,
    [rdv_id]        INT     NOT NULL,
    [user_id]            INT   NOT NULL,
    [Date_notification]        date NOT  NULL ,
	[description_notification]  Nvarchar(1000)  NULL,
	 CONSTRAINT PK_notification_rendezvous PRIMARY KEY (id_notification),
    CONSTRAINT FK_rendezvous_notification FOREIGN KEY (rdv_id) REFERENCES RendezVous(Id) on update cascade on delete cascade,
    CONSTRAINT FK_user_notification_rdv FOREIGN KEY (user_id) REFERENCES Utilisateur(id_user)  on update cascade on delete cascade
);

GO
CREATE TRIGGER Delete_notifcation_consultation on Notification_Consultation
after insert
as begin
   DELETE FROM Notification_Consultation
    WHERE Date_notification < DATEADD(MONTH, -2, GETDATE())
end

go
CREATE TRIGGER Delete_notifcation_patient on Notification_patient
after insert
as begin
   DELETE FROM Notification_patient
    WHERE Date_notification < DATEADD(MONTH, -2, GETDATE())
end;

go
CREATE TRIGGER Delete_notifcation_rdv on Notification_RendezVous
after insert
as begin
   DELETE FROM Notification_RendezVous
    WHERE Date_notification < DATEADD(MONTH, -2, GETDATE())
end;


--Create table information de cabinet

-- CREATE TABLE [dbo].[Info_Cabinet] (
--     [id_Cabinet]        INT        IDENTITY (1, 1) NOT NULL,
--     [Nom_Cabinet]            VARCHAR (500)    NOT NULL,
--     [Nom_Medcine]            VARCHAR (500)    NOT NULL,
-- 	[Nom_Medcine_AR]            nVARCHAR (500)     NULL,
-- 	[Specialite_medcine]            VARCHAR (500)     NULL,
--     [Specialite_medcine_AR]            nVARCHAR (500)     NULL,
-- 	[Address_Cabinet]            VARCHAR (900)     NULL,
-- 	[Phone_Cabinet]            VARCHAR (10)     NULL,
-- 	[Email_Cabinet]            VARCHAR (200)     NULL,
-- 	[Website_Cabinet]            VARCHAR (200)     NULL,
-- 	[Logo_Cabinet]            varbinary(max)     NULL,
--     PRIMARY KEY CLUSTERED ([id_Cabinet] ASC)
-- );

